window.godmodeComponentsInterop = {
    hackaroundFocus: function (element) {
        element.focus();
    }
};